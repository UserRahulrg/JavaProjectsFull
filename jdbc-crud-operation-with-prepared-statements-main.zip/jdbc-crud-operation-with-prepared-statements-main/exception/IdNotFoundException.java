package com.qsp.jdbc_prepared_statement_eve.exception;

public class IdNotFoundException extends Exception{

	public IdNotFoundException(String str) {
		super(str);
	}
}
